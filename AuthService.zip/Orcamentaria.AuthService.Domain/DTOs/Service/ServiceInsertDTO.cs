﻿namespace Orcamentaria.AuthService.Domain.DTOs.Service
{
    public class ServiceInsertDTO
    {
        public string Name { get; set; }
    }
}
