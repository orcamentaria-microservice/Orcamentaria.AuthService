﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orcamentaria.AuthService.Domain.DTOs.Service
{
    public class ServiceUpdateDTO
    {
        public string Name { get; set; }
        public bool Active { get; set; }
    }
}
