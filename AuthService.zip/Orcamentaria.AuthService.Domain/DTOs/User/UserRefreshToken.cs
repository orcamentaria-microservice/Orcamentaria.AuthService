﻿namespace Orcamentaria.AuthService.Domain.DTOs.User
{
    public class UserRefreshToken
    {
        public required string RefreshToken { get; set; }
    }
}
