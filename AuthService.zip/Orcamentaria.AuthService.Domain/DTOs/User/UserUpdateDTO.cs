﻿namespace Orcamentaria.AuthService.Domain.DTOs.User
{
    public class UserUpdateDTO
    {
        public string Name { get; set; }
        public bool Active { get; set; }
    }
}
